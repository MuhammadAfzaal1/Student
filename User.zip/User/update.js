var mongodb  = require('mongodb');
var url = 'mongodb://localhost:27017/person';

console.log("Add record");
console.log("Outside the Add record");
var MongoClient = mongodb.MongoClient;
MongoClient.connect(url, function(err,db){
		  
		  if(err)
		  {
			  
			console.log("Unable to connect to server" , err);
		  }
		  else
		  {
			  console.log("Connected to the server");
			 var http = require("http");
	var express = require("express");
	var app=express();
	app.use(express.bodyParser());
	app.use(app.router);
	http.createServer(app).listen(8081);
			 app.get('/Update' , function(req,res){
					res.sendfile('./Update.html');
			 });
			  console.log("outside the post");
			  
			  
			  app.post('/Update', function(req,res){

//				res.sendfile('/SignUp');
             //var MongoClient = mongodb.MongoClient;
		 
            console.log("inside the post");
			
			var firstName = req.body.firstName;
	        console.log(firstName);
	        var pass = req.body.pass;
			
			var collection = db.collection('employee');
	    collection.findOne({
			
			 firstName : firstName,
			 password  :  pass
		} , function(err , user)
		{
			if(err)
			{
				
				console.log("Unable to find User");
			}
			else if(user)
			{
				console.log("User is successfully found!");
			}
		});
	    
		
		});
	  
		  }
});