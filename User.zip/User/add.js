var mongodb  = require('mongodb');
var url = 'mongodb://localhost:27017/person';

console.log("Add record");
console.log("Outside the Add record");
var MongoClient = mongodb.MongoClient;
MongoClient.connect(url, function(err,db){
		  
		  if(err)
		  {
			  
			console.log("Unable to connect to server" , err);
		  }
		  else
		  {
			  console.log("Connected to the server");
			 var http = require("http");
	var express = require("express");
	var app=express();
	app.use(express.bodyParser());
	app.use(app.router);
	http.createServer(app).listen(8081);
			 app.get('/Add' , function(req,res){
					res.sendfile('./Add.html');
			 });
			  console.log("outside the post");
			  
			  
			  app.post('/Add', function(req,res){

//				res.sendfile('/SignUp');
             //var MongoClient = mongodb.MongoClient;
		 
            console.log("inside the post");

       
//      res.render('/SignUp');
	  var firstName = req.body.firstName;
	   console.log(firstName);
	  var lastName = req.body.lastName;
	  
	  var collection = db.collection('user');
			  var student = {
				   firstName : firstName,
				   lastName  : lastName,
				   
				    };
			  collection.insert(student , function(err , result){
				  
				  if(err)
				  {
					  
					  console.log("Unable to insert");
					  
				  }
				  else{
					  
					  console.log("Data is inserted");
					  
					  
				  }
				  db.close();
			  });
			  
		  
		
		  /*db.collection("employee").insert({"firstName":"fahad","lastName":"tariq"},function(err,result){
			  console.log(result);*/
});
	  
		  }
});
